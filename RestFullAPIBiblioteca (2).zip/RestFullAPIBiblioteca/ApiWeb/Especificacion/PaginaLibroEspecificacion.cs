﻿using Ardalis.Specification;
using Dominio.Entidades;

namespace ApiWeb.Especificacion
{
    public class PaginaLibroEspecificacion : Specification<Libro>
    {
        public  PaginaLibroEspecificacion(int tamanioPagina, int numeroPagina, String TituloLibro)
        {

            Query.Skip((numeroPagina - 1) * tamanioPagina)
            .Take(tamanioPagina);
            if (!string.IsNullOrEmpty(TituloLibro))
            {
                Query.Search(X => X.TituloLibro, "%" + TituloLibro + "%");
        
            }

        }


    }
}
