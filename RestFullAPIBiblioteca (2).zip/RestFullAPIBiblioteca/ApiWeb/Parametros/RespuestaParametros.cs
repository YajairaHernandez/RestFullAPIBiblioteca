﻿namespace ApiWeb.Parametros
{
    public class RespuestaParametros
    {
        public int NumeroPagina { get; set; }
        public int TamanioPagina { get; set; }

        public RespuestaParametros(int numeroPagina, int tamanioPagina) 
        {
            this.NumeroPagina = numeroPagina <1?1 :numeroPagina;
            this.TamanioPagina= tamanioPagina >10?10 :tamanioPagina;
        }
    }
}
