﻿namespace Aplicacion.Feautres.Libros.Consultas.ObtenerLibroPorId
{
    public interface IRequest<T1, T2>
    {
    }
}